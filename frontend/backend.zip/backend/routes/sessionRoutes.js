const express = require('express');
const router = express.Router();
const {protect: isAuthenticatedUser} = require('../middlewares/auth');
const { requestSession, acceptSession } = require('../controllers/sessionController');

router.route('/session/request').post(isAuthenticatedUser, requestSession);
router.route('/session/accept/:id').put(isAuthenticatedUser, acceptSession);

module.exports = router;