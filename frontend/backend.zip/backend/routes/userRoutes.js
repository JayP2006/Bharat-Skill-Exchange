const express = require('express');

const { getChatContacts, updateProfile, searchGurus } = require('../controllers/userController'); 
const { protect } = require('../middlewares/auth');
const router = express.Router();


router.get('/contacts', protect, getChatContacts);
router.route('/me/update').put(protect, updateProfile);
router.route('/search').get(searchGurus);
module.exports = router;
