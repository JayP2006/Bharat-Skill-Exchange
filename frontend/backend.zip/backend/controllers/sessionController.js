const SessionRequest = require('../models/SessionRequest');
const User = require('../models/User');
const { v4: uuidv4 } = require('uuid');

exports.requestSession = async (req, res) => {
  const { receiverId, skillName, requestedDate } = req.body;
  try {
    const sender = await User.findById(req.user.id);
    
    // Check Credit
    if (sender.walletBalance < 1) {
      return res.status(400).json({ message: "Insufficient Credits!" });
    }

    // Deduct Credit (Hold)
    sender.walletBalance -= 1;
    await sender.save();

    const session = await SessionRequest.create({
      sender: req.user.id,
      receiver: receiverId,
      skillName,
      requestedDate
    });

    res.status(201).json({ success: true, session });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.acceptSession = async (req, res) => {
  try {
    const session = await SessionRequest.findById(req.params.id);
    if (!session) return res.status(404).json({ message: "Session not found" });

    // Generate Video Link
    session.status = 'scheduled';
    session.meetingLink = `https://meet.jit.si/${uuidv4()}`;
    
    await session.save();
    res.status(200).json({ success: true, session });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};