const User = require('../models/User');

exports.getChatContacts = async (req, res, next) => {
  try {
    const currentUser = req.user;
    let contacts = [];

    if (currentUser.role === 'Shishya') {
      contacts = await User.find({ role: 'Guru' }).select('name avatar role');
    } 
    else if (currentUser.role === 'Guru') {
      contacts = await User.find({ role: 'Shishya' }).select('name avatar role');
    }

    const filteredContacts = contacts.filter(contact => contact._id.toString() !== currentUser.id.toString());

    res.status(200).json(filteredContacts);
  } catch (error) {
    console.error("Error fetching chat contacts:", error);
    next(error);
  }
};
exports.updateProfile = async (req, res) => {
  const { headline, about, location, skillsOffered, timezone, availability } = req.body;

  try {
    const newData = {
      headline, about, skillsOffered, timezone, availability
    };

    if (location && location.lat && location.lng) {
      newData.location = { 
        type: 'Point', 
        coordinates: [location.lng, location.lat] 
      };
    }

    const user = await User.findByIdAndUpdate(req.user.id, newData, { new: true });
    res.status(200).json({ success: true, user });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


exports.searchGurus = async (req, res) => {
  const { skill, lat, lng } = req.query;
  try {
    let query = {}; 

    if (skill) {
      query['skillsOffered.skillName'] = { $regex: skill, $options: 'i' };
    }

    if (lat && lng) {
      query.location = {
        $near: {
          $geometry: { type: "Point", coordinates: [parseFloat(lng), parseFloat(lat)] },
          $maxDistance: 10000 // 10km radius
        }
      };
    }

    const users = await User.find(query).select('-password');
    res.status(200).json({ success: true, users });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

